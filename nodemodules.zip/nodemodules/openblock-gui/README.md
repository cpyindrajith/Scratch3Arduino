# openblock-gui

![](https://img.shields.io/circleci/build/github/openblockcc/openblock-gui/develop) ![](https://img.shields.io/github/license/openblockcc/openblock-gui)

**OpenBlock GUI is a set of React components that comprise the interface for creating and running OpenBlock projects**

## Try OpenBlock Online

OpenBlock Online: [https://openblockcc.github.io/openblock-gui/develop/](https://openblockcc.github.io/openblock-gui/develop/)

<img src="docs\screenshoot1.png"/>

## Getting Start

Visit the wiki: [https://openblockcc.github.io/wiki/](https://openblockcc.github.io/wiki/)

## Contact me

China QQ group number: 933484739

Email: arthurzheng150@gmail.com

## Bug Report

You can submit the Bug log in Issues of this project.
